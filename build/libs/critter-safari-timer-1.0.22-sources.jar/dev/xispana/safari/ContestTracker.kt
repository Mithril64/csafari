package dev.xispana.safari

import net.minecraft.ChatFormatting
import net.minecraft.client.Minecraft
import net.minecraft.client.resources.sounds.SimpleSoundInstance
import net.minecraft.network.chat.Component
import net.minecraft.sounds.SoundEvents
import java.time.LocalTime

object ContestTracker {

    /**
     * True once we've already fired for the current second==0-on-a-mark-minute window, reset
     * back to false as soon as we observe a second that isn't 0. Client ticks run at 20Hz, far
     * finer than the 1-second window this flips on, so under normal play it can't double-fire
     * and can't miss a mark either. A severe lag spike that skips straight over second 0 would
     * miss that one alert - an acceptable, rare edge case, not worth tracking real elapsed time
     * for (the contest is on a real-world schedule regardless of local lag anyway).
     */
    private var armed = true

    fun tick() {
        val now = LocalTime.now()
        val onMark = now.second == 0 && now.minute in ContestSchedule.MARK_MINUTES
        if (onMark) {
            if (armed) {
                armed = false
                onContestStart()
            }
        } else {
            armed = true
        }
    }

    private fun onContestStart() {
        if (MiriaConfig.soundEnabled) playAlarm()
        if (MiriaConfig.chatEnabled) announce()
    }

    /**
     * Plays a local-only alert sound via the UI sound channel - never broadcast to other
     * players, and not tied to the player's in-world position (always audible, full volume).
     *
     * Vanilla's naming convention is CATEGORY_SOUND_ACTION; the bell's "use" (ding) sound is
     * `SoundEvents.BLOCK_BELL_USE`. If this field name doesn't resolve on your build, check
     * `net.minecraft.sounds.SoundEvents` for the current name and swap it in here - everything
     * else about this call is unaffected.
     */
    fun playAlarm() {
        Minecraft.getInstance().soundManager.play(SimpleSoundInstance.forUI(SoundEvents.BLOCK_BELL_USE, 1.0f))
    }

    private fun announce() {
        val mc = Minecraft.getInstance()
        mc.player?.sendSystemMessage(
            Component.literal("Miria's contest is starting now!").withStyle(ChatFormatting.LIGHT_PURPLE)
        )
    }
}
