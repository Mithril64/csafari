package dev.xispana.safari.mixin;

import dev.xispana.safari.PaintingHider;
import net.minecraft.client.renderer.entity.PaintingRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cancels PaintingRenderer.render() entirely while {@link PaintingHider#enabled} is true, so
 * vanilla Painting entities (wall art) simply don't draw - purely a client-side visual skip,
 * same as any clutter/x-ray toggle; it doesn't touch the painting's actual block/entity data,
 * so nothing else about the world changes and this is safe to flip on and off at will.
 *
 * `render` is the long-stable EntityRenderer name for this call across many versions - if
 * 26.1.2's unobfuscation pass renamed it, IntelliJ's "go to declaration" on PaintingRenderer
 * will show the current name; everything else about this mixin is unaffected by that rename.
 */
@Mixin(PaintingRenderer.class)
public abstract class PaintingRenderMixin {

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void csafari$hidePainting(CallbackInfo ci) {
        if (PaintingHider.INSTANCE.getEnabled()) {
            ci.cancel();
        }
    }
}
