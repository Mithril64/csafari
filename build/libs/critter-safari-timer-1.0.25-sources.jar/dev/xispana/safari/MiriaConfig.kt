package dev.xispana.safari

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import net.fabricmc.loader.api.FabricLoader
import java.nio.file.Files

private data class MiriaState(
    val hudEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val chatEnabled: Boolean = true
)

/** Persists the HUD/sound/chat toggles to disk so they survive a game restart. */
object MiriaConfig {

    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()
    private val file = FabricLoader.getInstance().configDir.resolve("critter-safari-miria.json")

    var hudEnabled: Boolean = true
        set(value) {
            field = value
            save()
        }

    var soundEnabled: Boolean = true
        set(value) {
            field = value
            save()
        }

    var chatEnabled: Boolean = true
        set(value) {
            field = value
            save()
        }

    init {
        load()
    }

    private fun load() {
        if (!Files.exists(file)) return
        runCatching {
            val text = Files.readString(file)
            val state = gson.fromJson(text, MiriaState::class.java) ?: return
            hudEnabled = state.hudEnabled
            soundEnabled = state.soundEnabled
            chatEnabled = state.chatEnabled
        }
    }

    fun save() {
        runCatching {
            Files.createDirectories(file.parent)
            Files.writeString(file, gson.toJson(MiriaState(hudEnabled, soundEnabled, chatEnabled)))
        }
    }
}
