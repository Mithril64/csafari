package dev.xispana.safari

/**
 * Session-only stats (not persisted - resets every game launch), tracking COMPLETION time
 * rather than run time: a run only "counts" the moment all 4 biomes are finished, using the
 * elapsed time at that exact instant. This is deliberately not the time the run/instance
 * ends - lingering around after finishing, or leaving early without ever completing, would
 * otherwise pollute the average or PB with numbers that don't reflect an actual clear speed.
 *
 * Completions under a minute are excluded from both the average and the PB. Critter Safari
 * instances run for a fixed length, so a "completion" detected in under 60 seconds is almost
 * certainly a false detection (a sidebar flicker, a stale run that never properly reset,
 * etc.) rather than a genuine clear - counting it would silently drag the average down with
 * a data point that was never real.
 */
object SessionStats {

    private const val MIN_VALID_MS = 60_000L

    private var completionCount: Int = 0
    private var totalCompletionMs: Long = 0L

    var pbElapsedMs: Long? = null
        private set

    /**
     * Call once a run finishes all 4 biomes, passing the elapsed time at that exact moment
     * (not the time the run/instance later ends). Silently ignored if under a minute.
     */
    fun recordCompletion(elapsedMs: Long) {
        if (elapsedMs < MIN_VALID_MS) return
        completionCount++
        totalCompletionMs += elapsedMs
        if (pbElapsedMs == null || elapsedMs < pbElapsedMs!!) {
            pbElapsedMs = elapsedMs
        }
    }

    val count: Int get() = completionCount

    /** Average completion time in ms across counted completions, or null if none counted yet. */
    val averageMs: Long?
        get() = if (completionCount == 0) null else totalCompletionMs / completionCount
}
