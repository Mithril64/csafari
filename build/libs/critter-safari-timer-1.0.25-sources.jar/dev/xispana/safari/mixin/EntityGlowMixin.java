package dev.xispana.safari.mixin;

import dev.xispana.safari.HideyhoDetector;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Forces the vanilla "glowing" outline (the same effect the Glowing status effect and
 * spectral arrows use, which the renderer draws through blocks via a stencil pass) for any
 * entity {@link HideyhoDetector} identifies as Hideyho.
 *
 * isCurrentlyGlowing() has been the Mojang-mapped name for this check across a very long
 * run of versions - of everything touched by this feature, it's the piece least likely to
 * have moved in 26.1.2's unobfuscation pass. Still, it's unverified against a real 26.1.2
 * client jar, so if the build fails on this file specifically, this method name is the
 * first thing to check (a decompiler or IntelliJ's "go to declaration" on Entity will show
 * the real name).
 */
@Mixin(Entity.class)
public abstract class EntityGlowMixin {

    @Inject(method = "isCurrentlyGlowing", at = @At("HEAD"), cancellable = true)
    private void csafari$forceHideyhoGlow(CallbackInfoReturnable<Boolean> cir) {
        Entity self = (Entity) (Object) this;
        if (HideyhoDetector.INSTANCE.matches(self)) {
            cir.setReturnValue(true);
        }
    }
}
