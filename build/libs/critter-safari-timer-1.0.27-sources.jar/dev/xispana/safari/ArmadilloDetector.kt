package dev.xispana.safari

import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.animal.armadillo.Armadillo

/**
 * Unlike Hideyho (a fake-player disguise matched by name), Armadillo is a real vanilla mob
 * type - so this is a plain type check, not name-based detection. It's deliberately not
 * scoped to an active safari run the way HideyhoDetector is: Armadillo isn't one of the 37
 * Critter Safari critters, it's the ordinary overworld mob (wolf-armor scute grinding), so
 * the ESP is useful wherever you actually run into one, safari or not.
 *
 * Armadillo's package (`net.minecraft.world.entity.animal.armadillo.Armadillo`) is confirmed
 * against real Mojang-mapped output (mappings.dev, snapshot 25w08a) rather than guessed -
 * same verification standard as the Painting fix, after getting that one wrong twice in a
 * row by guessing blind.
 */
object ArmadilloDetector {

    var enabled: Boolean = true

    fun matches(entity: Entity): Boolean {
        if (!enabled) return false
        return entity is Armadillo
    }
}
