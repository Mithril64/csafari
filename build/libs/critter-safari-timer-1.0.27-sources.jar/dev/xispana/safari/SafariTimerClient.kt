package dev.xispana.safari

import com.mojang.brigadier.arguments.IntegerArgumentType
import com.mojang.brigadier.builder.LiteralArgumentBuilder
import net.fabricmc.api.ClientModInitializer
// 26.1 Fabric API rename: ClientCommandManager -> ClientCommands.
import net.fabricmc.fabric.api.client.command.v2.ClientCommands
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements
import net.minecraft.ChatFormatting
import net.minecraft.network.chat.Component
// 26.1 vanilla rename: ResourceLocation -> Identifier.
import net.minecraft.resources.Identifier

object SafariTimerClient : ClientModInitializer {

    const val MOD_ID = "critter-safari-timer"

    override fun onInitializeClient() {
        // ALLOW_GAME is cancellable: returning false hides the vanilla line. GAME (the
        // non-cancellable variant) can only observe messages, not suppress them.
        ClientReceiveMessageEvents.ALLOW_GAME.register { message, _ ->
            SafariTracker.handleChatLine(message.string)
        }

        ClientTickEvents.END_CLIENT_TICK.register { client ->
            SafariTracker.tick(client)
            // Runs on its own real-world schedule, independent of any safari run.
            ContestTracker.tick()
        }

        // Leaving the server ends any run in progress.
        ClientPlayConnectionEvents.DISCONNECT.register { _, _ ->
            SafariTracker.end(announce = false)
        }

        // HudRenderCallback was removed; HudElementRegistry is the replacement.
        HudElementRegistry.attachElementAfter(
            VanillaHudElements.MISC_OVERLAYS,
            Identifier.fromNamespaceAndPath(MOD_ID, "safari-overlay")
        ) { graphics, tickCounter -> SafariHud.render(graphics, tickCounter) }

        HudElementRegistry.attachElementAfter(
            VanillaHudElements.MISC_OVERLAYS,
            Identifier.fromNamespaceAndPath(MOD_ID, "miria-overlay")
        ) { graphics, tickCounter -> MiriaHud.render(graphics, tickCounter) }

        ClientCommandRegistrationCallback.EVENT.register { dispatcher, _ ->
            dispatcher.register(buildCommand())
            dispatcher.register(buildMiriaCommand())
        }
    }

    private fun buildCommand(): LiteralArgumentBuilder<FabricClientCommandSource> =
        ClientCommands.literal("safari")
            .executes { ctx ->
                val run = SafariTracker.currentRun ?: SafariTracker.lastRun
                if (run == null) {
                    ctx.source.sendFeedback(
                        Component.literal("No safari run tracked yet.").withStyle(ChatFormatting.GRAY)
                    )
                } else {
                    val title = if (SafariTracker.currentRun != null) "Current run" else "Last run"
                    SafariTracker.printSummary(run, title)
                }
                1
            }
            .then(
                ClientCommands.literal("missing").executes { ctx ->
                    val run = SafariTracker.currentRun ?: SafariTracker.lastRun
                    if (run == null) {
                        ctx.source.sendFeedback(
                            Component.literal("No safari run tracked yet.").withStyle(ChatFormatting.GRAY)
                        )
                    } else {
                        SafariTracker.printMissing(run)
                    }
                    1
                }
            )
            .then(
                ClientCommands.literal("pb").executes {
                    SafariTracker.printBests(); 1
                }
            )
            .then(
                ClientCommands.literal("session").executes {
                    SafariTracker.printSessionStats(); 1
                }
            )
            .then(
                ClientCommands.literal("start").executes {
                    SafariTracker.startManual(); 1
                }
            )
            .then(
                ClientCommands.literal("stop").executes {
                    SafariTracker.stopManual(); 1
                }
            )
            .then(
                ClientCommands.literal("reset").executes {
                    SafariTracker.reset(); 1
                }
            )
            .then(
                ClientCommands.literal("hud").executes { ctx ->
                    SafariHud.enabled = !SafariHud.enabled
                    ctx.source.sendFeedback(
                        Component.literal("HUD ${if (SafariHud.enabled) "on" else "off"}")
                            .withStyle(ChatFormatting.YELLOW)
                    )
                    1
                }
            )
            .then(
                ClientCommands.literal("esp").executes { ctx ->
                    HideyhoDetector.enabled = !HideyhoDetector.enabled
                    ctx.source.sendFeedback(
                        Component.literal("Hideyho ESP ${if (HideyhoDetector.enabled) "on" else "off"}")
                            .withStyle(ChatFormatting.YELLOW)
                    )
                    1
                }
            )
            .then(
                ClientCommands.literal("paintings").executes { ctx ->
                    PaintingHider.enabled = !PaintingHider.enabled
                    ctx.source.sendFeedback(
                        Component.literal("Paintings ${if (PaintingHider.enabled) "hidden" else "visible"}")
                            .withStyle(ChatFormatting.YELLOW)
                    )
                    1
                }
            )
            .then(
                ClientCommands.literal("armadillo").executes { ctx ->
                    ArmadilloDetector.enabled = !ArmadilloDetector.enabled
                    ctx.source.sendFeedback(
                        Component.literal("Armadillo ESP ${if (ArmadilloDetector.enabled) "on" else "off"}")
                            .withStyle(ChatFormatting.YELLOW)
                    )
                    1
                }
            )
            .then(
                ClientCommands.literal("announce")
                    .executes { ctx ->
                        AnnounceConfig.enabled = !AnnounceConfig.enabled
                        ctx.source.sendFeedback(
                            Component.literal("Auto party-chat announcements ${if (AnnounceConfig.enabled) "on" else "off"}.")
                                .withStyle(ChatFormatting.YELLOW)
                        )
                        1
                    }
                    .then(
                        ClientCommands.literal("add")
                            .then(
                                ClientCommands.argument("seconds", IntegerArgumentType.integer(1))
                                    .executes { ctx ->
                                        val seconds = IntegerArgumentType.getInteger(ctx, "seconds")
                                        AnnounceConfig.addMark(seconds)
                                        ctx.source.sendFeedback(
                                            Component.literal("Will post missing list to /pc at ${seconds}s.")
                                                .withStyle(ChatFormatting.YELLOW)
                                        )
                                        1
                                    }
                            )
                    )
                    .then(
                        ClientCommands.literal("remove")
                            .then(
                                ClientCommands.argument("seconds", IntegerArgumentType.integer(1))
                                    .executes { ctx ->
                                        val seconds = IntegerArgumentType.getInteger(ctx, "seconds")
                                        AnnounceConfig.removeMark(seconds)
                                        ctx.source.sendFeedback(
                                            Component.literal("Removed ${seconds}s.").withStyle(ChatFormatting.YELLOW)
                                        )
                                        1
                                    }
                            )
                    )
                    .then(
                        ClientCommands.literal("list").executes {
                            SafariTracker.printAnnounceMarks(); 1
                        }
                    )
                    .then(
                        ClientCommands.literal("complete")
                            .then(
                                ClientCommands.literal("on").executes { ctx ->
                                    AnnounceConfig.completeToPartyChat = true
                                    ctx.source.sendFeedback(
                                        Component.literal("Biome-complete messages will also post to /pc.")
                                            .withStyle(ChatFormatting.YELLOW)
                                    )
                                    1
                                }
                            )
                            .then(
                                ClientCommands.literal("off").executes { ctx ->
                                    AnnounceConfig.completeToPartyChat = false
                                    ctx.source.sendFeedback(
                                        Component.literal("Biome-complete messages stay local only.")
                                            .withStyle(ChatFormatting.YELLOW)
                                    )
                                    1
                                }
                            )
                    )
                    .then(
                        ClientCommands.literal("clear").executes { ctx ->
                            AnnounceConfig.clearMarks()
                            ctx.source.sendFeedback(
                                Component.literal("Cleared all announce times.").withStyle(ChatFormatting.YELLOW)
                            )
                            1
                        }
                    )
            )

    private fun buildMiriaCommand(): LiteralArgumentBuilder<FabricClientCommandSource> =
        ClientCommands.literal("miria")
            .executes { ctx ->
                val seconds = ContestSchedule.secondsUntilNext(java.time.LocalTime.now())
                ctx.source.sendFeedback(
                    Component.literal("Next contest in ${ContestSchedule.formatCountdown(seconds)}")
                        .withStyle(ChatFormatting.LIGHT_PURPLE)
                )
                1
            }
            .then(
                ClientCommands.literal("hud").executes { ctx ->
                    MiriaConfig.hudEnabled = !MiriaConfig.hudEnabled
                    ctx.source.sendFeedback(
                        Component.literal("Miria HUD ${if (MiriaConfig.hudEnabled) "on" else "off"}")
                            .withStyle(ChatFormatting.YELLOW)
                    )
                    1
                }
            )
            .then(
                ClientCommands.literal("sound").executes { ctx ->
                    MiriaConfig.soundEnabled = !MiriaConfig.soundEnabled
                    ctx.source.sendFeedback(
                        Component.literal("Miria alarm sound ${if (MiriaConfig.soundEnabled) "on" else "off"}")
                            .withStyle(ChatFormatting.YELLOW)
                    )
                    1
                }
            )
            .then(
                ClientCommands.literal("chat").executes { ctx ->
                    MiriaConfig.chatEnabled = !MiriaConfig.chatEnabled
                    ctx.source.sendFeedback(
                        Component.literal("Miria chat message ${if (MiriaConfig.chatEnabled) "on" else "off"}")
                            .withStyle(ChatFormatting.YELLOW)
                    )
                    1
                }
            )
            .then(
                ClientCommands.literal("test").executes { ctx ->
                    ContestTracker.playAlarm()
                    ctx.source.sendFeedback(
                        Component.literal("Test alarm played.").withStyle(ChatFormatting.GRAY)
                    )
                    1
                }
            )
}
