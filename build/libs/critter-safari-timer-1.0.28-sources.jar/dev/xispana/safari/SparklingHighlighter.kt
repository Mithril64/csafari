package dev.xispana.safari

import net.minecraft.client.Minecraft
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.player.Player

/**
 * Scans nearby entities for "SPARKLING" in their nametag, to give a loud, hard-to-miss visual
 * cue (the screen border, see SparklingBorderOverlay) even if you're mid-fight or not looking
 * at chat right when one spawns.
 *
 * Checks two places that text could show up, since different critters use different disguise
 * mechanics elsewhere in this mod: a fake-player disguise's GameProfile name (the same
 * mechanism HideyhoDetector matches Hideyho on) and a plain custom-name component (the
 * mechanism a reskinned/renamed real mob would use, like Armadillo if Hypixel ever gives it
 * one). Matching either covers both without needing to know which one Hypixel actually uses
 * for Sparkling - cheap insurance against guessing wrong, which this mod has already done
 * enough of today.
 *
 * Scoped to an active safari run (same as Hideyho ESP) since Sparkling critters only exist
 * there - no reason to scan every entity in the world the rest of the time. Throttled to
 * every 5 ticks (4 scans/sec) rather than all 20, since a full nearby-entity scan every
 * single tick is unnecessary for something that only needs to feel responsive, not instant.
 */
object SparklingHighlighter {

    var enabled: Boolean = true

    private const val MATCH = "sparkling"
    private const val SCAN_INTERVAL_TICKS = 5
    private var tickCounter = 0

    @Volatile
    var nearby: Boolean = false
        private set

    fun tick() {
        if (!enabled || SafariTracker.currentRun == null) {
            nearby = false
            tickCounter = 0
            return
        }
        tickCounter++
        if (tickCounter < SCAN_INTERVAL_TICKS) return
        tickCounter = 0

        val level = Minecraft.getInstance().level
        nearby = level != null && level.entitiesForRendering().any(::matches)
    }

    private fun matches(entity: Entity): Boolean {
        if (entity is Player && entity.gameProfile.name.lowercase().contains(MATCH)) return true
        val customName = entity.customName?.string ?: return false
        return customName.lowercase().contains(MATCH)
    }
}
