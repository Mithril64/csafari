package dev.xispana.safari

/**
 * Parses Critter Safari chat lines.
 *
 * Usernames are never matched as critters for two reasons:
 *  1. the critter is always read from a fixed grammatical slot
 *     ("You caught a X and ...", "... catching a X!"), never from the whole line;
 *  2. the extracted name is then validated against the 37 known critters.
 *
 * So "LOOT SHARE! You received 2x Billygoat Shard from Xispana catching a Billygoat!"
 * yields Billygoat, and a player literally named Billygoat still resolves correctly.
 */
object ChatParser {

    sealed interface Event {
        /** You personally captured it -> counts for the Critterdex. */
        data class Capture(val critter: Critter, val sparkling: Boolean) : Event

        /** Someone else captured it; you got the shard but no Critterdex entry. */
        data class LootShare(val critter: Critter, val player: String, val sparkling: Boolean) : Event

        /** The lobby-wide SPARKLING broadcast line. */
        data class SparklingBroadcast(val critter: Critter, val player: String) : Event
    }

    // CAPTURE! You caught a Hideonwall and gained a Hideonwall Shard!
    // CAPTURE! You caught a SPARKLING Foxtrot and received a Rainbow Feather and 10x Foxtrot Shard!
    private val CAPTURE = Regex(
        """^CAPTURE!\s+You caught an?\s+(SPARKLING\s+)?(.+?)\s+and\s+(?:gained|received)\b"""
    )

    // LOOT SHARE! You received 2x Billygoat Shard from Xispana catching a Billygoat!
    private val LOOT_SHARE = Regex(
        """^LOOT SHARE!\s+You received\s+.+?\s+from\s+(\S+)\s+catching an?\s+(SPARKLING\s+)?(.+?)!\s*$"""
    )

    // SPARKLING! Xispana caught a SPARKLING Foxtrot!
    private val SPARKLING = Regex(
        """^SPARKLING!\s+(\S+)\s+caught a SPARKLING\s+(.+?)!\s*$"""
    )

    fun parse(rawLine: String): Event? {
        // Strip section-sign colour codes and collapse whitespace.
        val line = rawLine.replace(Regex("\u00A7."), "").trim().replace(Regex("\\s+"), " ")
        if (line.isEmpty()) return null

        CAPTURE.find(line)?.let { m ->
            val critter = Critters.resolve(m.groupValues[2]) ?: return null
            return Event.Capture(critter, m.groupValues[1].isNotEmpty())
        }

        LOOT_SHARE.find(line)?.let { m ->
            val critter = Critters.resolve(m.groupValues[3]) ?: return null
            return Event.LootShare(critter, m.groupValues[1], m.groupValues[2].isNotEmpty())
        }

        SPARKLING.find(line)?.let { m ->
            val critter = Critters.resolve(m.groupValues[2]) ?: return null
            return Event.SparklingBroadcast(critter, m.groupValues[1])
        }

        return null
    }
}
