package dev.xispana.safari

import net.minecraft.client.DeltaTracker
import net.minecraft.client.Minecraft
// 26.1.2 renamed GuiGraphics -> GuiGraphicsExtractor as part of the rendering-pipeline rewrite.
import net.minecraft.client.gui.GuiGraphicsExtractor

object SafariHud {

    var enabled: Boolean = true
    var x: Int = 4
    var y: Int = 4

    private const val WHITE = 0xFFFFFFFF.toInt()
    private const val AQUA = 0xFF55FFFF.toInt()
    private const val GREEN = 0xFF55FF55.toInt()
    private const val YELLOW = 0xFFFFFF55.toInt()
    private const val GRAY = 0xFFAAAAAA.toInt()
    private const val GOLD = 0xFFFFAA00.toInt()

    private data class Segment(val text: String, val color: Int)

    fun render(graphics: GuiGraphicsExtractor, @Suppress("UNUSED_PARAMETER") delta: DeltaTracker) {
        if (!enabled) return
        val run = SafariTracker.currentRun ?: return
        val mc = Minecraft.getInstance()

        val font = mc.font
        val missingByBiome = run.missingByBiome()
        val lines: List<List<Segment>> = buildList {
            add(listOf(Segment("Critter Safari", AQUA)))
            add(listOf(Segment("Time  ${SafariRun.formatTime(run.elapsedMs())}", WHITE)))
            for (stat in run.biomeStats()) {
                val stats = Segment("${stat.biome.display.padEnd(8)}${stat.seen}/${stat.total}", GREEN)
                val missing = missingByBiome[stat.biome]
                if (missing.isNullOrEmpty()) {
                    add(listOf(stats))
                } else {
                    add(listOf(stats, Segment("   " + missing.joinToString(", ") { it.name }, GRAY)))
                }
            }
            add(listOf(Segment("Caught ${run.totalCaptures}  Shared ${run.totalLootShares}", GRAY)))
            run.msPerUnique()?.let { add(listOf(Segment("Pace  ${SafariRun.formatTime(it)}/unique", YELLOW))) }
            if (run.sparkling.isNotEmpty()) {
                add(listOf(Segment("Sparkling ${run.sparkling.size}", GOLD)))
            }
        }

        var cy = y
        for (segments in lines) {
            var cx = x
            for (segment in segments) {
                // GuiGraphicsExtractor.text(font, text, x, y, color, shadow) replaced drawString().
                graphics.text(font, segment.text, cx, cy, segment.color, true)
                cx += font.width(segment.text)
            }
            cy += font.lineHeight + 1
        }
    }
}
