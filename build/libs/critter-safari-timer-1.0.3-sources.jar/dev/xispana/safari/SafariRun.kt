package dev.xispana.safari

/**
 * A single safari instance. The timer is wall-clock based and pauses if you
 * somehow leave the instance without the run ending.
 */
class SafariRun {

    private var startedAt: Long = System.currentTimeMillis()
    private var accumulatedMs: Long = 0L
    private var running: Boolean = true

    /** Critters you personally captured (these are the ones that fill the Critterdex). */
    val captured: LinkedHashSet<Critter> = LinkedHashSet()

    /** Critters caught by anyone in the instance, including loot-shared ones. */
    val seen: LinkedHashSet<Critter> = LinkedHashSet()

    val sparkling: LinkedHashSet<Critter> = LinkedHashSet()

    var totalCaptures: Int = 0
        private set
    var totalLootShares: Int = 0
        private set

    /** Milliseconds since the first capture of each critter, for pace stats. */
    val firstCatchMs: LinkedHashMap<Critter, Long> = LinkedHashMap()

    fun elapsedMs(): Long =
        accumulatedMs + if (running) System.currentTimeMillis() - startedAt else 0L

    fun pause() {
        if (!running) return
        accumulatedMs += System.currentTimeMillis() - startedAt
        running = false
    }

    fun resume() {
        if (running) return
        startedAt = System.currentTimeMillis()
        running = true
    }

    fun onCapture(critter: Critter, isSparkling: Boolean) {
        totalCaptures++
        if (captured.add(critter)) firstCatchMs.putIfAbsent(critter, elapsedMs())
        seen.add(critter)
        if (isSparkling) sparkling.add(critter)
    }

    fun onLootShare(critter: Critter, isSparkling: Boolean) {
        totalLootShares++
        seen.add(critter)
        if (isSparkling) sparkling.add(critter)
    }

    fun onSparklingBroadcast(critter: Critter) {
        sparkling.add(critter)
        seen.add(critter)
    }

    fun missing(): List<Critter> = Critters.ALL.filterNot { captured.contains(it) }

    fun missingByBiome(): Map<Biome, List<Critter>> = missing().groupBy { it.biome }

    /** Per-biome dex (captured) / seen counts, in a fixed biome order. */
    fun biomeStats(): List<BiomeStat> = Biome.entries.map { biome ->
        val total = Critters.BY_BIOME[biome]?.size ?: 0
        BiomeStat(
            biome = biome,
            captured = captured.count { it.biome == biome },
            seen = seen.count { it.biome == biome },
            total = total
        )
    }

    data class BiomeStat(val biome: Biome, val captured: Int, val seen: Int, val total: Int)

    private val completedBiomes: MutableSet<Biome> = mutableSetOf()

    /**
     * Call right after a new (personal) capture. Returns true exactly once, the moment
     * [biome]'s dex hits 100% - false on every call before or after that moment.
     */
    fun checkBiomeCompletion(biome: Biome): Boolean {
        if (biome in completedBiomes) return false
        val total = Critters.BY_BIOME[biome]?.size ?: 0
        if (total == 0 || captured.count { it.biome == biome } < total) return false
        completedBiomes.add(biome)
        return true
    }

    /** Average time between your unique captures, or null before the second one. */
    fun msPerUnique(): Long? =
        if (captured.isEmpty()) null else elapsedMs() / captured.size

    companion object {
        fun formatTime(ms: Long): String {
            val total = ms / 1000
            val h = total / 3600
            val m = (total % 3600) / 60
            val s = total % 60
            return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
        }
    }
}
