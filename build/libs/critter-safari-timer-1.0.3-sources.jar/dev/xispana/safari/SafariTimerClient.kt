package dev.xispana.safari

import com.mojang.brigadier.builder.LiteralArgumentBuilder
import net.fabricmc.api.ClientModInitializer
// 26.1 Fabric API rename: ClientCommandManager -> ClientCommands.
import net.fabricmc.fabric.api.client.command.v2.ClientCommands
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements
import net.minecraft.ChatFormatting
import net.minecraft.network.chat.Component
// 26.1 vanilla rename: ResourceLocation -> Identifier.
import net.minecraft.resources.Identifier

object SafariTimerClient : ClientModInitializer {

    const val MOD_ID = "critter-safari-timer"

    override fun onInitializeClient() {
        // ALLOW_GAME is cancellable: returning false hides the vanilla line. GAME (the
        // non-cancellable variant) can only observe messages, not suppress them.
        ClientReceiveMessageEvents.ALLOW_GAME.register { message, _ ->
            SafariTracker.handleChatLine(message.string)
        }

        ClientTickEvents.END_CLIENT_TICK.register { client ->
            SafariTracker.tick(client)
        }

        // Leaving the server ends any run in progress.
        ClientPlayConnectionEvents.DISCONNECT.register { _, _ ->
            SafariTracker.end(announce = false)
        }

        // HudRenderCallback was removed; HudElementRegistry is the replacement.
        HudElementRegistry.attachElementAfter(
            VanillaHudElements.MISC_OVERLAYS,
            Identifier.fromNamespaceAndPath(MOD_ID, "safari-overlay")
        ) { graphics, tickCounter -> SafariHud.render(graphics, tickCounter) }

        ClientCommandRegistrationCallback.EVENT.register { dispatcher, _ ->
            dispatcher.register(buildCommand())
        }
    }

    private fun buildCommand(): LiteralArgumentBuilder<FabricClientCommandSource> =
        ClientCommands.literal("safari")
            .executes { ctx ->
                val run = SafariTracker.currentRun ?: SafariTracker.lastRun
                if (run == null) {
                    ctx.source.sendFeedback(
                        Component.literal("No safari run tracked yet.").withStyle(ChatFormatting.GRAY)
                    )
                } else {
                    val title = if (SafariTracker.currentRun != null) "Current run" else "Last run"
                    SafariTracker.printSummary(run, title)
                }
                1
            }
            .then(
                ClientCommands.literal("missing").executes { ctx ->
                    val run = SafariTracker.currentRun ?: SafariTracker.lastRun
                    if (run == null) {
                        ctx.source.sendFeedback(
                            Component.literal("No safari run tracked yet.").withStyle(ChatFormatting.GRAY)
                        )
                    } else {
                        SafariTracker.printMissing(run)
                    }
                    1
                }
            )
            .then(
                ClientCommands.literal("start").executes {
                    SafariTracker.startManual(); 1
                }
            )
            .then(
                ClientCommands.literal("stop").executes {
                    SafariTracker.stopManual(); 1
                }
            )
            .then(
                ClientCommands.literal("reset").executes {
                    SafariTracker.reset(); 1
                }
            )
            .then(
                ClientCommands.literal("hud").executes { ctx ->
                    SafariHud.enabled = !SafariHud.enabled
                    ctx.source.sendFeedback(
                        Component.literal("HUD ${if (SafariHud.enabled) "on" else "off"}")
                            .withStyle(ChatFormatting.YELLOW)
                    )
                    1
                }
            )
}
