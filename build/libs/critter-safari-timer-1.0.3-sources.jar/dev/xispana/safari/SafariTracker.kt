package dev.xispana.safari

import net.minecraft.ChatFormatting
import net.minecraft.client.Minecraft
import net.minecraft.network.chat.Component

object SafariTracker {

    var currentRun: SafariRun? = null
        private set

    /** Last finished run, so /safari can still show a summary after you leave. */
    var lastRun: SafariRun? = null
        private set

    /** Set manually by /safari start|stop; suppresses automatic detection. */
    private var manualOverride: Boolean = false

    private var wasInSafari: Boolean = false
    private var tickCounter: Int = 0

    /** Raw line -> last-seen timestamp, to catch Hypixel occasionally sending a line twice. */
    private val recentLines: LinkedHashMap<String, Long> = LinkedHashMap()
    private const val DEDUPE_WINDOW_MS = 2000L

    fun tick(mc: Minecraft) {
        if (mc.player == null) return
        if (manualOverride) return

        // Sidebar only needs checking a few times a second.
        if (++tickCounter % 10 != 0) return

        val inSafari = LocationDetector.inSafari(mc)
        if (inSafari && !wasInSafari) {
            begin(announce = true)
        } else if (!inSafari && wasInSafari) {
            end(announce = true)
        }
        wasInSafari = inSafari
    }

    fun begin(announce: Boolean) {
        currentRun = SafariRun()
        if (announce) {
            send(Component.literal("Safari started - timer running.").withStyle(ChatFormatting.AQUA))
        }
    }

    fun end(announce: Boolean) {
        val run = currentRun ?: return
        run.pause()
        lastRun = run
        currentRun = null
        if (announce) printSummary(run, "Safari finished")
    }

    fun startManual() {
        manualOverride = true
        wasInSafari = true
        begin(announce = true)
    }

    fun stopManual() {
        end(announce = true)
        manualOverride = false
        wasInSafari = false
    }

    fun reset() {
        currentRun?.let {
            currentRun = SafariRun()
            send(Component.literal("Run reset.").withStyle(ChatFormatting.YELLOW))
        }
    }

    /**
     * Called from the cancellable ALLOW_GAME hook. Returns true to let the vanilla line
     * through unchanged, false to hide it (because we already sent our own version of it).
     */
    fun handleChatLine(rawLine: String): Boolean {
        val event = ChatParser.parse(rawLine) ?: return true // not a safari line, leave it alone
        val run = currentRun ?: return true // not tracking a run, nothing to replace it with

        if (isDuplicate(rawLine)) return false // Hypixel resent the same line; drop it silently

        when (event) {
            is ChatParser.Event.Capture -> {
                val isNew = !run.captured.contains(event.critter)
                run.onCapture(event.critter, event.sparkling)
                if (isNew) {
                    announceNew(run, event.critter, event.sparkling)
                    if (run.checkBiomeCompletion(event.critter.biome)) {
                        announceBiomeComplete(run, event.critter.biome)
                    }
                } else {
                    announceRepeat(run, event.critter, event.sparkling)
                }
            }
            is ChatParser.Event.LootShare -> {
                run.onLootShare(event.critter, event.sparkling)
                announceLootShare(event.critter, event.player, event.sparkling)
            }
            is ChatParser.Event.SparklingBroadcast -> {
                run.onSparklingBroadcast(event.critter)
                announceSparklingBroadcast(event.critter, event.player)
            }
        }
        return false // always replace the vanilla line with our own compact version
    }

    private fun isDuplicate(rawLine: String): Boolean {
        val now = System.currentTimeMillis()
        recentLines.entries.removeIf { now - it.value > DEDUPE_WINDOW_MS }
        val last = recentLines.put(rawLine, now)
        return last != null && now - last <= DEDUPE_WINDOW_MS
    }

    private fun announceNew(run: SafariRun, critter: Critter, sparkling: Boolean) {
        val prefix = if (sparkling) "SPARKLING " else ""
        send(
            Component.literal("New: ").withStyle(ChatFormatting.GREEN)
                .append(
                    Component.literal("$prefix${critter.name}")
                        .withStyle(if (sparkling) ChatFormatting.GOLD else ChatFormatting.WHITE)
                )
                .append(
                    Component.literal("  (${run.captured.size}/${Critters.TOTAL} at ${SafariRun.formatTime(run.elapsedMs())})")
                        .withStyle(ChatFormatting.GRAY)
                )
        )
    }

    private fun announceRepeat(run: SafariRun, critter: Critter, sparkling: Boolean) {
        val prefix = if (sparkling) "SPARKLING " else ""
        send(
            Component.literal("Caught ").withStyle(ChatFormatting.GRAY)
                .append(Component.literal("$prefix${critter.name}").withStyle(ChatFormatting.WHITE))
                .append(Component.literal(" (already in dex)").withStyle(ChatFormatting.DARK_GRAY))
        )
    }

    private fun announceLootShare(critter: Critter, player: String, sparkling: Boolean) {
        val prefix = if (sparkling) "SPARKLING " else ""
        send(
            Component.literal("Shared: ").withStyle(ChatFormatting.DARK_GREEN)
                .append(
                    Component.literal("$prefix${critter.name}")
                        .withStyle(if (sparkling) ChatFormatting.GOLD else ChatFormatting.WHITE)
                )
                .append(Component.literal(" from $player").withStyle(ChatFormatting.GRAY))
        )
    }

    private fun announceSparklingBroadcast(critter: Critter, player: String) {
        send(
            Component.literal("\u2726 ").withStyle(ChatFormatting.GOLD)
                .append(Component.literal("$player found SPARKLING ${critter.name}!").withStyle(ChatFormatting.YELLOW))
        )
    }

    private fun announceBiomeComplete(run: SafariRun, biome: Biome) {
        send(
            Component.literal("\u2605 ").withStyle(ChatFormatting.GOLD)
                .append(Component.literal("${biome.display} biome complete!").withStyle(ChatFormatting.GREEN))
                .append(
                    Component.literal("  (${SafariRun.formatTime(run.elapsedMs())})")
                        .withStyle(ChatFormatting.GRAY)
                )
        )
    }

    fun printSummary(run: SafariRun, title: String) {
        send(Component.literal("--- $title ---").withStyle(ChatFormatting.AQUA))
        send(line("Time", SafariRun.formatTime(run.elapsedMs())))
        send(line("Uniques", "${run.seen.size}/${Critters.TOTAL}"))
        for (stat in run.biomeStats()) {
            send(line("  ${stat.biome.display}", "${stat.seen}/${stat.total}"))
        }
        send(line("Captures", run.totalCaptures.toString()))
        send(line("Loot shares", run.totalLootShares.toString()))
        run.msPerUnique()?.let { send(line("Avg per unique", SafariRun.formatTime(it))) }
        if (run.sparkling.isNotEmpty()) {
            send(line("Sparkling", run.sparkling.joinToString(", ") { it.name }))
        }
    }

    fun printMissing(run: SafariRun) {
        val missing = run.missingByBiome()
        if (run.missing().isEmpty()) {
            send(Component.literal("Full dex this run.").withStyle(ChatFormatting.GREEN))
            return
        }
        send(Component.literal("--- Missing (${run.missing().size}) ---").withStyle(ChatFormatting.AQUA))

        val combined = Component.literal("")
        var first = true
        for (biome in Biome.entries) {
            val list = missing[biome] ?: continue
            if (!first) combined.append(Component.literal("   ").withStyle(ChatFormatting.DARK_GRAY))
            combined.append(Component.literal("${biome.display}: ").withStyle(ChatFormatting.YELLOW))
            combined.append(
                Component.literal(list.joinToString(", ") { "${it.name} [${it.rarity.short}]" })
                    .withStyle(ChatFormatting.WHITE)
            )
            first = false
        }
        send(combined)
    }

    private fun line(label: String, value: String): Component =
        Component.literal("$label: ").withStyle(ChatFormatting.GRAY)
            .append(Component.literal(value).withStyle(ChatFormatting.WHITE))

    private fun send(component: Component) {
        // Player.displayClientMessage was removed in 26.1.2; sendSystemMessage replaced it.
        Minecraft.getInstance().player?.sendSystemMessage(component)
    }
}
