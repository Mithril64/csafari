package dev.xispana.safari

import net.minecraft.client.Minecraft
import net.minecraft.client.resources.sounds.SimpleSoundInstance
// 26.1 vanilla rename: ResourceLocation -> Identifier.
import net.minecraft.resources.Identifier
import net.minecraft.sounds.SoundEvent
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.player.Player

/**
 * Scans nearby entities for Sparkling critters, two different ways, since neither alone is
 * reliable:
 *
 * 1. Nametag text containing "SPARKLING" - works for most of them, cheap and exact once it
 *    matches, but per your report some Sparkling critters don't actually have that word in
 *    their nametag at all.
 * 2. For critters #1 misses: resolve the entity's plain name (no "SPARKLING" needed) via
 *    Critters.matchAtStart, then check ParticleTracker for a shiny-looking particle recorded
 *    near that entity very recently (the cross/glint effect in your screenshot). This is the
 *    fallback for exactly the case you described - "Honeybug" with no "SPARKLING" text but the
 *    sparkle visual still playing around it.
 *
 * SHINY_PARTICLE_HINTS below is a best-effort GUESS at the vanilla particle type id(s) Hypixel
 * reuses for that effect - I can't know the real one without being in-game. Run
 * `/safari particles` while standing near a confirmed Sparkling critter and tell me what it
 * prints if detection via particles isn't picking critters up; I'll swap the real id in once
 * you report it back, same as how Hideyho's chat-line matching got fixed earlier.
 *
 * Scoped to an active safari run (Sparkling critters only exist there) and throttled to every
 * 5 ticks (4 scans/sec) - a full nearby-entity scan every single tick isn't needed for
 * something that only has to feel responsive, not instant.
 */
object SparklingHighlighter {

    var enabled: Boolean = true

    private const val MATCH = "sparkling"
    private const val SCAN_INTERVAL_TICKS = 5
    private var tickCounter = 0

    // Best-effort guesses at the particle type Hypixel's shiny/sparkle effect reuses.
    // Unverified - correct via `/safari particles` if this list turns out wrong.
    val SHINY_PARTICLE_HINTS: Set<String> = setOf(
        "totem_of_undying", "end_rod", "firework", "witch", "enchant", "crit"
    )
    private const val PARTICLE_RADIUS = 2.5
    private const val PARTICLE_MAX_AGE_MS = 1500L

    @Volatile
    var nearby: Boolean = false
        private set

    /** Display names of the currently-matched Sparkling critter(s), for the on-screen label. */
    @Volatile
    var names: Set<String> = emptySet()
        private set

    // Entity ids matched on the previous scan, so the sound only fires when a NEW critter
    // starts matching rather than retriggering every scan while one stays in range.
    private var previouslyMatched: Set<Int> = emptySet()

    private val SHINY_SOUND: SoundEvent =
        SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("csafari", "shiny"))

    fun tick() {
        if (!enabled || SafariTracker.currentRun == null) {
            nearby = false
            names = emptySet()
            previouslyMatched = emptySet()
            tickCounter = 0
            return
        }
        tickCounter++
        if (tickCounter < SCAN_INTERVAL_TICKS) return
        tickCounter = 0

        val level = Minecraft.getInstance().level
        if (level == null) {
            nearby = false
            names = emptySet()
            return
        }

        val matchedIds = mutableSetOf<Int>()
        val matchedNames = mutableSetOf<String>()

        for (entity in level.entitiesForRendering()) {
            val name = resolveSparklingName(entity) ?: continue
            matchedIds.add(entity.id)
            matchedNames.add(name)
        }

        nearby = matchedIds.isNotEmpty()
        names = matchedNames

        // Fire the alert sound once per newly-appearing match, not every scan.
        if (matchedIds.any { it !in previouslyMatched }) {
            playShinySound()
        }
        previouslyMatched = matchedIds
    }

    /**
     * Returns a display name if [entity] looks like a Sparkling critter, or null. Tries the
     * literal-text match first (cheap, exact), then falls back to particle proximity for
     * critters whose nametag doesn't say "SPARKLING".
     */
    private fun resolveSparklingName(entity: Entity): String? {
        val rawTexts = listOfNotNull(
            (entity as? Player)?.gameProfile?.name,
            entity.customName?.string
        )

        // Channel 1: literal "SPARKLING" text somewhere in the name.
        for (raw in rawTexts) {
            if (!raw.lowercase().contains(MATCH)) continue
            // Strip the "SPARKLING" marker (any case/position) and resolve what's left to a
            // real critter name; fall back to the cleaned raw text if it doesn't resolve.
            val stripped = Regex("(?i)sparkling").replace(raw, "").trim()
            return Critters.matchAtStart(stripped)?.name ?: stripped.ifBlank { raw.trim() }
        }

        // Channel 2: no "SPARKLING" text, but the raw name resolves to a real critter AND a
        // shiny-looking particle was recorded near this entity very recently.
        for (raw in rawTexts) {
            val critter = Critters.matchAtStart(raw.trim()) ?: continue
            val near = ParticleTracker.hasNearby(
                entity.x, entity.y, entity.z,
                PARTICLE_RADIUS, SHINY_PARTICLE_HINTS, PARTICLE_MAX_AGE_MS
            )
            if (near) return critter.name
        }

        return null
    }

    private fun playShinySound() {
        Minecraft.getInstance().soundManager.play(SimpleSoundInstance.forUI(SHINY_SOUND, 1.0f))
    }
}
