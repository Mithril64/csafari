package dev.xispana.safari

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import net.fabricmc.loader.api.FabricLoader
import net.minecraft.client.Minecraft
import java.nio.file.Files
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter

/**
 * Reads the SkyBlock sidebar for Miria's Contest rarity-tier line - the screenshot you sent
 * showed "UNCOMMON with 389" / "Rare requires +611" - to work out whether this contest's
 * ticket is already secured. Per your report, Hypixel only guarantees a ticket once the tier
 * reaches UNCOMMON or higher; sitting at COMMON means nothing's secured yet.
 *
 * Reuses LocationDetector.sidebarLines (the same scoreboard read already proven working for
 * safari-location detection) rather than a new mixin, so this carries none of the usual
 * API-guessing risk - it's plain string matching over text that mod already reads safely.
 *
 * Caches the result for the rest of the 20-minute contest window once it's known, rather than
 * needing the sidebar line visible every single tick: a contest's tier only ever goes up, so
 * once it's been UNCOMMON+, it stays secured for that window even if you walk away from
 * Torrhus and the sidebar stops showing it. The cache is tagged with which contest window it
 * belongs to (the window's start time, to the minute) so it's automatically treated as stale
 * the moment the next contest starts, without needing any direct link to ContestTracker.
 * Persisted to disk (`critter-safari-miria-ticket.json`), so a game restart mid-contest still
 * remembers "secured" instead of forgetting and showing nothing until the sidebar is read
 * again.
 */
object MiriaTicketDetector {

    // Matches a line like "UNCOMMON with 389" - word-boundaried tier name followed by
    // "with <number>", so it only fires on the actual tier-progress line and not some
    // unrelated sidebar text that happens to contain one of these words. Alternation order
    // doesn't matter for correctness here (word boundaries already stop "COMMON" matching
    // inside "UNCOMMON"), but listing longest-first keeps it obviously intentional.
    private val TIER_LINE = Regex("(?i)\\b(LEGENDARY|EPIC|RARE|UNCOMMON|COMMON)\\b\\s+with\\s+\\d+")

    private const val SCAN_INTERVAL_TICKS = 10 // a couple of times a second is plenty
    private var tickCounter = 0

    private val WINDOW_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm")

    private data class TicketState(val windowId: String, val secured: Boolean)

    private val gson: Gson = GsonBuilder().create()
    private val file = FabricLoader.getInstance().configDir.resolve("critter-safari-miria-ticket.json")

    /** Which 20-minute contest window the cached result below belongs to, or null if none yet. */
    private var cachedWindowId: String? = null

    /** Null while this window's tier hasn't been read yet (no cache, no live sidebar match). */
    @Volatile
    var ticketSecured: Boolean? = null
        private set

    init {
        load()
    }

    private fun currentWindowId(now: LocalDateTime): String =
        now.minusSeconds(ContestSchedule.secondsSinceLastMark(now.toLocalTime()))
            .format(WINDOW_FORMAT)

    fun tick(mc: Minecraft) {
        if (++tickCounter < SCAN_INTERVAL_TICKS) return
        tickCounter = 0

        val now = LocalDateTime.now()
        val windowId = currentWindowId(now)

        // A new contest window started since the cache was last written - whatever was cached
        // belonged to the previous one, so it no longer applies.
        if (windowId != cachedWindowId) {
            cachedWindowId = null
            ticketSecured = null
        }

        val match = LocationDetector.sidebarLines(mc).firstNotNullOfOrNull { TIER_LINE.find(it) }
        val tier = match?.groupValues?.get(1)?.uppercase() ?: return // sidebar not showing it right now - keep whatever's cached

        val secured = tier != "COMMON"
        if (windowId == cachedWindowId && ticketSecured == secured) return // no change - nothing new to persist
        cachedWindowId = windowId
        ticketSecured = secured
        save()
    }

    private fun load() {
        if (!Files.exists(file)) return
        runCatching {
            val state = gson.fromJson(Files.readString(file), TicketState::class.java) ?: return
            cachedWindowId = state.windowId
            ticketSecured = state.secured
        }
    }

    private fun save() {
        val windowId = cachedWindowId ?: return
        val secured = ticketSecured ?: return
        runCatching {
            Files.createDirectories(file.parent)
            Files.writeString(file, gson.toJson(TicketState(windowId, secured)))
        }
    }
}
