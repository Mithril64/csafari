package dev.xispana.safari

import net.minecraft.client.Minecraft
import net.minecraft.network.chat.Component
import net.minecraft.world.scores.DisplaySlot
import net.minecraft.world.scores.PlayerTeam

/**
 * Reads the SkyBlock sidebar to work out where you are.
 *
 * Everything is wrapped defensively: if a scoreboard signature changes in a future
 * Minecraft version this degrades to "unknown location" instead of crashing, and you
 * can still drive the timer manually with /csafari start and /csafari stop.
 */
object LocationDetector {

    private const val SAFARI_MARKER = "critter safari"

    fun sidebarLines(mc: Minecraft): List<String> = runCatching {
        val scoreboard = mc.level?.scoreboard ?: return emptyList()
        val objective = scoreboard.getDisplayObjective(DisplaySlot.SIDEBAR) ?: return emptyList()

        val lines = ArrayList<String>()
        lines.add(objective.displayName.string)

        for (entry in scoreboard.listPlayerScores(objective)) {
            val owner: String = entry.owner()
            val team: PlayerTeam? = scoreboard.getPlayersTeam(owner)
            val rendered: Component = PlayerTeam.formatNameForTeam(team, Component.literal(owner))
            lines.add(rendered.string.replace(Regex("\u00A7."), ""))
        }
        lines
    }.getOrDefault(emptyList())

    /** True while the sidebar says you are inside the Critter Safari. */
    fun inSafari(mc: Minecraft): Boolean =
        sidebarLines(mc).any { it.lowercase().contains(SAFARI_MARKER) }

    /** True if the sidebar looks like SkyBlock at all (used to avoid false negatives on lag). */
    fun onSkyBlock(mc: Minecraft): Boolean =
        sidebarLines(mc).firstOrNull()?.lowercase()?.contains("skyblock") == true
}
