package dev.xispana.safari

import net.minecraft.ChatFormatting
import net.minecraft.client.Minecraft
import net.minecraft.client.resources.sounds.SimpleSoundInstance
import net.minecraft.network.chat.Component
// 26.1 vanilla rename: ResourceLocation -> Identifier.
import net.minecraft.resources.Identifier
import net.minecraft.sounds.SoundEvent
import org.slf4j.LoggerFactory
import java.time.LocalTime

object ContestTracker {

    // Logged to latest.log rather than echoed in chat - an earlier chat-echoed debug line
    // (embedding the matched raw line, which still contained "Torrhus") fed right back into
    // this same detector and looped until the client crashed. A log line can't do that.
    private val LOGGER = LoggerFactory.getLogger("csafari-contest")

    /**
     * True once we've already fired for the current second==0-on-a-mark-minute window, reset
     * back to false as soon as we observe a second that isn't 0. Client ticks run at 20Hz, far
     * finer than the 1-second window this flips on, so under normal play it can't double-fire
     * and can't miss a mark either. A severe lag spike that skips straight over second 0 would
     * miss that one alert - an acceptable, rare edge case, not worth tracking real elapsed time
     * for (the contest is on a real-world schedule regardless of local lag anyway).
     */
    private var armed = true

    fun tick() {
        val now = LocalTime.now()
        val onMark = now.second == 0 && now.minute in ContestSchedule.MARK_MINUTES
        if (onMark) {
            if (armed) {
                armed = false
                onContestStart()
            }
        } else {
            armed = true
        }
    }

    private fun onContestStart() {
        if (MiriaConfig.soundEnabled) playAlarm()
        if (MiriaConfig.chatEnabled) announce()
        // Always ping at the scheduled start, regardless of ticketSecured - this is a brand
        // new contest window, so by definition nobody's secured a ticket in it yet (the
        // detector itself resets ticketSecured back to false the moment a new window begins).
        if (MiriaConfig.partyChatEnabled) {
            postToPartyChat()
            lastPartyPingMs = System.currentTimeMillis()
        }
    }

    // --- Party-chat "ready" ping, re-sent when someone warps in mid-contest ---

    private const val PARTY_PING_COOLDOWN_MS = 60_000L
    private var lastPartyPingMs: Long = 0L

    // Confirmed exact broadcast text: " » {username} is traveling to Torrhus Canyon FOLLOW".
    // Matching on the specific phrase "is traveling to Torrhus Canyon" rather than the bare
    // word "Torrhus" - the bare word was too loose and could trip on an ordinary party-chat
    // message that just mentions the place, where this exact phrase is the server's travel
    // broadcast and nothing else would plausibly say it.
    private val WARP_TORRHUS = Regex("(?i)is\\s+traveling\\s+to\\s+Torrhus\\s+Canyon")

    /**
     * Called from the non-cancelling chat listener for every line the client receives. Not
     * tied to any safari-run tracking - this fires any time the travel broadcast shows up,
     * contest active or not, same as the scheduled ping does regardless of what you're doing.
     */
    fun handleChatLine(rawLine: String) {
        if (!WARP_TORRHUS.containsMatchIn(rawLine)) return
        LOGGER.info("[csafari] matched Torrhus travel line: {}", rawLine)
        if (!MiriaConfig.partyChatEnabled) {
            LOGGER.info("[csafari] party-chat ping is toggled off, not posting")
            return
        }
        if (MiriaTicketDetector.ticketSecured) {
            LOGGER.info("[csafari] ticket already secured, not posting")
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastPartyPingMs < PARTY_PING_COOLDOWN_MS) {
            LOGGER.info("[csafari] still on cooldown ({}ms left), not posting", PARTY_PING_COOLDOWN_MS - (now - lastPartyPingMs))
            return
        }
        lastPartyPingMs = now
        postToPartyChat()
    }

    private fun postToPartyChat() {
        if (!PartyTracker.inParty) {
            LOGGER.info("[csafari] not in a party, skipping party-chat post")
            return
        }
        // connection.sendCommand sends exactly what typing "/pc <text>" and hitting enter
        // would - straight to the server, same mechanism SafariTracker's party-chat
        // announcements already use.
        val connection = Minecraft.getInstance().player?.connection
        if (connection == null) {
            LOGGER.info("[csafari] postToPartyChat: no player/connection, cannot send")
            return
        }
        LOGGER.info("[csafari] sending /pc Miria's contest is ready!")
        connection.sendCommand("pc Miria's contest is ready!")
    }

    /**
     * The bell's "use" (ding) sound, built directly from its resource-location id rather than
     * a `SoundEvents.XXX` constant. The constant name (we first tried `BELL_BLOCK_USE`, then
     * `BLOCK_BELL_USE` - both wrong) is exactly the kind of Java identifier 26.1.2's
     * unobfuscation pass could rename out from under us; the id "block.bell.use" is the actual
     * game/sound-system data the wiki documents and is far more stable than any Java field
     * name pointing at it. `createVariableRangeEvent` is the standard Mojang-mapped factory
     * for building a SoundEvent from an id without needing it to already exist as a constant.
     */
    private val ALARM_SOUND: SoundEvent =
        SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("minecraft", "block.bell.use"))

    /**
     * Plays a local-only alert sound via the UI sound channel - never broadcast to other
     * players, and not tied to the player's in-world position (always audible, full volume).
     */
    fun playAlarm() {
        Minecraft.getInstance().soundManager.play(SimpleSoundInstance.forUI(ALARM_SOUND, 1.0f))
    }

    private fun announce() {
        val mc = Minecraft.getInstance()
        mc.player?.sendSystemMessage(
            Component.literal("Miria's contest is starting now!").withStyle(ChatFormatting.LIGHT_PURPLE)
        )
    }
}
