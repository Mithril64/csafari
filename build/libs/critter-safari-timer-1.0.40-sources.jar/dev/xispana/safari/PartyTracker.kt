package dev.xispana.safari

import org.slf4j.LoggerFactory

/**
 * Best-effort "are we currently in a Hypixel party" tracker, built from watching the server's
 * own party-system chat lines - Hypixel doesn't expose a party-membership API to the client,
 * so there's nothing more direct to read.
 *
 * Defaults to **not** in a party until actual join evidence is seen. That's the safe default:
 * a wrong "yes" means a `/pc` send silently fails server-side (Hypixel just replies "You are
 * not currently in a party!" to you, nobody else sees anything) - whereas a wrong "no" just
 * costs a ping that doesn't go out, which is obvious and harmless by comparison.
 *
 * The line wording below is reconstructed from Hypixel's well-known party-system messages,
 * not verified against your own screen the way this mod's other chat matching has been (e.g.
 * ContestTracker's Torrhus line, tuned after you reported the exact text). If party detection
 * ever seems wrong - refuses to send while you ARE in a party, or sends while you're not -
 * paste the actual chat line involved and I'll tighten these the same way.
 */
object PartyTracker {

    private val LOGGER = LoggerFactory.getLogger("csafari-party")

    @Volatile
    var inParty: Boolean = false
        private set

    // Lines meaning "you're now in a party" - creating one, joining one, or an invite landing.
    private val JOINED = Regex(
        "(?i)(you have joined|you'll be partying with|you have created a party|invite has been accepted)"
    )

    // Lines meaning "you're no longer in a party" - including Hypixel's own error reply to a
    // party-only command when there isn't one, which doubles as a self-correcting signal if
    // JOINED above ever mismatches.
    private val LEFT = Regex(
        "(?i)(you have left the party|you left the party|you have been removed from the party|" +
            "the party was disbanded|you have disbanded the party|you are not currently in a party)"
    )

    fun handleChatLine(rawLine: String) {
        when {
            LEFT.containsMatchIn(rawLine) -> setInParty(false, rawLine)
            JOINED.containsMatchIn(rawLine) -> setInParty(true, rawLine)
        }
    }

    private fun setInParty(value: Boolean, cause: String) {
        if (inParty == value) return
        inParty = value
        LOGGER.info("[csafari] party state -> {} (matched: {})", value, cause)
    }
}
