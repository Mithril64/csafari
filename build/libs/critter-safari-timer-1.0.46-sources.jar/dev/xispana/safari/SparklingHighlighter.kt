package dev.xispana.safari

import net.minecraft.client.Minecraft
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.player.Player

/**
 * Scans nearby entities for Sparkling critters, two different ways, since neither alone is
 * reliable:
 *
 * 1. Nametag text containing "SPARKLING" - works for most of them, cheap and exact once it
 *    matches, but per your report some Sparkling critters don't actually have that word in
 *    their nametag at all.
 * 2. For critters #1 misses: resolve the entity's plain name (no "SPARKLING" needed) via
 *    Critters.matchAtStart, then check ParticleTracker for a shiny-looking particle recorded
 *    near that entity very recently (the cross/glint effect in your screenshot). This is the
 *    fallback for exactly the case you described - "Honeybug" with no "SPARKLING" text but the
 *    sparkle visual still playing around it.
 *
 * SHINY_PARTICLE_HINTS below used to be a best-effort guess list (totem_of_undying, end_rod,
 * firework, witch, enchant, crit) - too broad, and per your report `end_rod` was false-
 * flagging on unrelated particles. Replaced with the real id you confirmed via
 * `/csafari particles`: `wax_on` (the same particle vanilla uses for an axe un-waxing copper -
 * reused here, evidently, for the shiny glint).
 *
 * Scoped to an active safari run (Sparkling critters only exist there) and throttled to every
 * 5 ticks (4 scans/sec) - a full nearby-entity scan every single tick isn't needed for
 * something that only has to feel responsive, not instant.
 */
object SparklingHighlighter {

    var enabled: Boolean = true

    private const val MATCH = "sparkling"
    private const val SCAN_INTERVAL_TICKS = 5
    private var tickCounter = 0

    // Confirmed via /csafari particles - the only particle id the shiny effect actually uses.
    val SHINY_PARTICLE_HINTS: Set<String> = setOf("wax_on")
    private const val PARTICLE_RADIUS = 2.5
    private const val PARTICLE_MAX_AGE_MS = 1500L

    @Volatile
    var nearby: Boolean = false
        private set

    /** Display names of the currently-matched Sparkling critter(s), for the on-screen label. */
    @Volatile
    var names: Set<String> = emptySet()
        private set

    // Entity ids matched on the previous scan, so the sound only fires when a NEW critter
    // starts matching rather than retriggering every scan while one stays in range.
    private var previouslyMatched: Set<Int> = emptySet()

    // Per-entity-id cooldown, NOT a single global one - per your correction, two different
    // Sparklings nearby at once should each still get their own sound. This only blocks a
    // given entity id from re-triggering the jingle for 60s after it last played, which is
    // what stops a single Sparkling that walks out of render range and back in (or otherwise
    // gets re-scanned as "newly appearing") from spamming it. nearby/names (and therefore the
    // border) are completely untouched by this and keep updating live the whole time.
    private const val SOUND_COOLDOWN_MS = 60_000L
    private val lastSoundMsById = mutableMapOf<Int, Long>()

    /** One scanned entity's result, for the /csafari sparkling debug command - lets you check
     *  what the last scan actually saw and matched without needing to spot the border in game. */
    data class ScanEntry(
        val entityId: Int,
        val rawText: String,
        val critterGuess: String?,
        val matched: Boolean
    )

    @Volatile
    var lastScan: List<ScanEntry> = emptyList()
        private set

    fun tick() {
        if (!enabled || SafariTracker.currentRun == null) {
            nearby = false
            names = emptySet()
            previouslyMatched = emptySet()
            tickCounter = 0
            return
        }
        tickCounter++
        if (tickCounter < SCAN_INTERVAL_TICKS) return
        tickCounter = 0

        val level = Minecraft.getInstance().level
        if (level == null) {
            nearby = false
            names = emptySet()
            return
        }

        val matchedIds = mutableSetOf<Int>()
        val matchedNames = mutableSetOf<String>()
        val scanLog = mutableListOf<ScanEntry>()

        for (entity in level.entitiesForRendering()) {
            val name = resolveSparklingName(entity, scanLog) ?: continue
            matchedIds.add(entity.id)
            matchedNames.add(name)
        }

        nearby = matchedIds.isNotEmpty()
        names = matchedNames
        lastScan = scanLog

        // Fire the alert sound once per newly-appearing match, not every scan - each id is
        // checked against its own cooldown, so a second distinct Sparkling isn't blocked by
        // the first one's recent sound.
        for (id in matchedIds) {
            if (id !in previouslyMatched) playShinySound(id)
        }
        previouslyMatched = matchedIds
    }

    /**
     * Returns a display name if [entity] looks like a Sparkling critter, or null. Tries the
     * literal-text match first (cheap, exact), then falls back to particle proximity for
     * critters whose nametag doesn't say "SPARKLING". Every candidate it looks at - matched or
     * not - gets appended to [debug] so /csafari sparkling debug can show the full scan.
     */
    private fun resolveSparklingName(entity: Entity, debug: MutableList<ScanEntry>): String? {
        val rawTexts = listOfNotNull(
            (entity as? Player)?.gameProfile?.name,
            entity.customName?.string
        )

        // Channel 1: literal "SPARKLING" text somewhere in the name.
        for (raw in rawTexts) {
            if (!raw.lowercase().contains(MATCH)) continue
            // Strip the "SPARKLING" marker (any case/position) and resolve what's left to a
            // real critter name; fall back to the cleaned raw text if it doesn't resolve.
            val stripped = Regex("(?i)sparkling").replace(raw, "").trim()
            val resolved = Critters.matchAtStart(stripped)?.name ?: stripped.ifBlank { raw.trim() }
            debug.add(ScanEntry(entity.id, raw, resolved, matched = true))
            return resolved
        }

        // Channel 2: no "SPARKLING" text, but the raw name resolves to a real critter AND a
        // shiny-looking particle was recorded near this entity very recently.
        for (raw in rawTexts) {
            val critter = Critters.matchAtStart(raw.trim()) ?: continue
            val near = ParticleTracker.hasNearby(
                entity.x, entity.y, entity.z,
                PARTICLE_RADIUS, SHINY_PARTICLE_HINTS, PARTICLE_MAX_AGE_MS
            )
            debug.add(ScanEntry(entity.id, raw, critter.name, matched = near))
            if (near) return critter.name
        }

        return null
    }

    private fun playShinySound(entityId: Int) {
        val now = System.currentTimeMillis()
        val last = lastSoundMsById[entityId]
        if (last != null && now - last < SOUND_COOLDOWN_MS) return
        lastSoundMsById[entityId] = now
        // Plays whichever of the two jingles is currently selected (/csafari shinysound to
        // toggle) - see ShinySoundConfig for the Pokemon/Wynncraft options and persistence.
        ShinySoundConfig.play()
    }
}
