package dev.xispana.safari

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import net.fabricmc.loader.api.FabricLoader
import net.minecraft.client.resources.sounds.SimpleSoundInstance
// 26.1 vanilla rename: ResourceLocation -> Identifier.
import net.minecraft.resources.Identifier
import net.minecraft.sounds.SoundEvent
import java.nio.file.Files

/** The two shiny-found jingles to choose from, each backed by its own sound event/file under
 *  assets/csafari/sounds. "Pokemon" is the original (`shiny.ogg`); "Wynncraft" is the one you
 *  sent (Wynntils OST - "Infinite Pleasure (Mythic Found)", converted to .ogg). */
enum class ShinySound(val displayName: String, soundPath: String) {
    POKEMON("Pokemon", "shiny"),
    WYNNCRAFT("Wynncraft", "shiny_wynncraft");

    val event: SoundEvent = SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("csafari", soundPath))

    companion object {
        fun fromName(name: String): ShinySound? = entries.firstOrNull { it.name == name }
    }
}

private data class ShinySoundState(val selected: String = ShinySound.POKEMON.name, val volumePercent: Int = 100)

/** Persists which shiny-found sound is selected (and how loud it plays), the same way
 *  MiriaConfig persists its toggles. */
object ShinySoundConfig {

    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()
    private val file = FabricLoader.getInstance().configDir.resolve("critter-safari-shiny-sound.json")

    var selected: ShinySound = ShinySound.POKEMON
        set(value) {
            field = value
            save()
        }

    /** 0-100, stored as a whole percentage (easier to type as a command argument than a
     *  0.0-1.0 float) and converted down to SimpleSoundInstance's 0.0-1.0 range in play(). */
    var volumePercent: Int = 100
        set(value) {
            field = value.coerceIn(0, 100)
            save()
        }

    init {
        load()
    }

    /** Cycles to the next option and returns it, for a single toggle command. */
    fun cycle(): ShinySound {
        val next = ShinySound.entries[(selected.ordinal + 1) % ShinySound.entries.size]
        selected = next
        return next
    }

    fun play() {
        if (volumePercent <= 0) return
        val volume = volumePercent / 100f
        net.minecraft.client.Minecraft.getInstance().soundManager.play(SimpleSoundInstance.forUI(selected.event, volume))
    }

    private fun load() {
        if (!Files.exists(file)) return
        runCatching {
            val text = Files.readString(file)
            val state = gson.fromJson(text, ShinySoundState::class.java) ?: return
            selected = ShinySound.fromName(state.selected) ?: ShinySound.POKEMON
            volumePercent = state.volumePercent
        }
    }

    private fun save() {
        runCatching {
            Files.createDirectories(file.parent)
            Files.writeString(file, gson.toJson(ShinySoundState(selected.name, volumePercent)))
        }
    }
}
