package dev.xispana.safari

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents
import net.minecraft.ChatFormatting
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.screens.ChatScreen
import net.minecraft.network.chat.ClickEvent
import net.minecraft.network.chat.Component
import net.minecraft.network.chat.Style
import org.slf4j.LoggerFactory
import java.util.Optional

/**
 * "Click anywhere to accept Hideyho": while chat is open and a Hideyho "Sure" prompt is pending,
 * a left click ANYWHERE on the screen runs that prompt's command, instead of needing to hit the
 * small clickable chat text exactly. Same idea as SkyblockOverhaul's Sphinx solver click handler
 * (SphinxSolver.onGuiMouseClick -> any left click on a ChatScreen), but with nothing to solve:
 * Hideyho's prompt has one deterministic accept option, so this only widens the click target. It
 * still takes one real click from you per prompt - it never fires on its own.
 *
 * HOW THE PROMPT IS FOUND: every game message is scanned for clickable segments (style.clickEvent
 * is a RunCommand). The real prompt (from a screenshot) is "[MOB] Hideyho: How about it?" followed
 * by one line, "Select an option: [Sure] [No thanks...]". A segment is taken as the accept option
 * if EITHER
 *   - its text is "Sure" (brackets stripped) and a Hideyho line was seen within RECENT_HIDEYHO_MS, or
 *   - its command mentions "hideyho" and its text doesn't start with "No".
 * The command itself is still captured straight off the message instead of hardcoded (the real
 * command string isn't known), so whatever Hypixel actually uses is what gets sent.
 *
 * LOGGING: every candidate (and every Hideyho line with no clickable part) is written to
 * latest.log under "csafari-hideyho" - log only, never chat, since an earlier chat echo of a
 * matched line re-triggered its own detector and crashed the client. If this doesn't fire in
 * game, that log shows the real line/command to fix the matching from.
 *
 * Expires after PENDING_TTL_MS so a stale prompt can't be accepted by an unrelated chat click.
 */
object HideyhoAutoAccept {

    private val LOGGER = LoggerFactory.getLogger("csafari-hideyho")

    var enabled: Boolean = true

    private const val PENDING_TTL_MS = 30_000L
    private const val RECENT_HIDEYHO_MS = 10_000L

    private val FORMAT_CODE = Regex("§.")

    private data class Pending(val command: String, val atMs: Long)

    @Volatile
    private var pending: Pending? = null
    private var lastHideyhoLineMs = 0L

    /** Called from the GAME message listener for every received line. */
    fun onMessage(message: Component) {
        if (!enabled) return
        val plain = FORMAT_CODE.replace(message.string, "").trim()
        val mentionsHideyho = plain.contains("hideyho", ignoreCase = true)
        if (mentionsHideyho) lastHideyhoLineMs = System.currentTimeMillis()

        // Collect every clickable RunCommand segment of this message with its visible text.
        val clickable = mutableListOf<Pair<String, String>>() // visible text to command
        message.visit(
            { style: Style, text: String ->
                val click = style.clickEvent
                if (click is ClickEvent.RunCommand) clickable.add(text.trim() to click.command())
                Optional.empty<Any>()
            },
            Style.EMPTY
        )

        if (clickable.isEmpty()) {
            if (mentionsHideyho) LOGGER.info("[csafari] Hideyho line, no clickable part: {}", plain)
            return
        }

        val recentHideyho = System.currentTimeMillis() - lastHideyhoLineMs <= RECENT_HIDEYHO_MS

        // Confirmed from a real screenshot: "Select an option: [Sure] [No thanks...]" is ONE line
        // with two clickable segments, shown with square brackets ("[Sure]"), and the Hideyho
        // name only appears in the lines ABOVE it ("[MOB] Hideyho: How about it?"). So: strip
        // brackets before comparing, and pick "Sure" explicitly - never just the first clickable
        // whose command mentions hideyho, since "No thanks..." almost certainly does too.
        fun label(t: String) = t.trim().trim('[', ']').trim().trimEnd('.')

        val sure = clickable.firstOrNull { (text, _) -> recentHideyho && label(text).equals("Sure", ignoreCase = true) }
            ?: clickable.firstOrNull { (text, command) ->
                command.contains("hideyho", ignoreCase = true) && !label(text).startsWith("No", ignoreCase = true)
            }
        if (sure != null) {
            LOGGER.info("[csafari] Hideyho prompt captured: text='{}' command='{}'", sure.first, sure.second)
            pending = Pending(sure.second, System.currentTimeMillis())
            return
        }
        if (mentionsHideyho) {
            LOGGER.info("[csafari] Hideyho line had clickables but none matched: {}", clickable)
        }
    }

    /** Registers the click-anywhere handler on every screen; acts only on ChatScreen. */
    fun registerClickHandler() {
        ScreenEvents.AFTER_INIT.register { _, screen, _, _ ->
            if (screen !is ChatScreen) return@register
            ScreenMouseEvents.beforeMouseClick(screen).register { _, click ->
                if (click.buttonInfo().button != 0) return@register
                accept()
            }
        }
    }

    private fun accept() {
        if (!enabled) return
        val p = pending ?: return
        pending = null // one prompt, one accept - also stops a double fire on a second click
        if (System.currentTimeMillis() - p.atMs > PENDING_TTL_MS) {
            LOGGER.info("[csafari] pending Hideyho prompt expired, ignoring click")
            return
        }
        val connection = Minecraft.getInstance().player?.connection ?: return
        LOGGER.info("[csafari] accepting Hideyho prompt: /{}", p.command.removePrefix("/"))
        connection.sendCommand(p.command.removePrefix("/"))
    }

    /** True while a prompt is waiting for a click - lets the toggle command report status. */
    fun hasPending(): Boolean =
        pending?.let { System.currentTimeMillis() - it.atMs <= PENDING_TTL_MS } ?: false

    fun notice(): Component =
        Component.literal("Hideyho click-to-accept ${if (enabled) "on" else "off"}")
            .withStyle(ChatFormatting.YELLOW)
}
