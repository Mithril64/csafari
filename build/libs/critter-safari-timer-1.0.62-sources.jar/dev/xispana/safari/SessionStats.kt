package dev.xispana.safari

/**
 * Session-only stats (not persisted - resets every game launch) counting every real run you
 * play out, not just the ones where you caught all 37 critters.
 *
 * A full-dex clear is recorded at the instant all 4 biomes finish (its elapsed time at that
 * exact moment) rather than whenever the instance later ends - lingering around after
 * finishing shouldn't inflate that run's time. Any other run - however many critters it ended
 * with, 35/37 included - is instead recorded when it ends, using however long it actually
 * ran. Either way, a run only counts once (SafariTracker/SafariRun guard against double
 * counting the same run both ways).
 *
 * Runs under a minute are excluded entirely. Critter Safari instances run for a fixed length,
 * so anything detected as "finished" in under 60 seconds is almost certainly a false
 * detection (a sidebar flicker, a stale run that never properly reset, etc.) rather than a
 * genuine run - counting it would silently drag the average down with a data point that was
 * never real.
 */
object SessionStats {

    private const val MIN_VALID_MS = 60_000L

    private var completionCount: Int = 0
    private var totalCompletionMs: Long = 0L

    var pbElapsedMs: Long? = null
        private set

    /**
     * Call once per run - either the moment it clears all 4 biomes, or whenever it ends if it
     * never did - passing the elapsed time at that moment. Silently ignored if under a minute.
     */
    fun recordCompletion(elapsedMs: Long) {
        if (elapsedMs < MIN_VALID_MS) return
        completionCount++
        totalCompletionMs += elapsedMs
        if (pbElapsedMs == null || elapsedMs < pbElapsedMs!!) {
            pbElapsedMs = elapsedMs
        }
    }

    val count: Int get() = completionCount

    /** Average completion time in ms across counted completions, or null if none counted yet. */
    val averageMs: Long?
        get() = if (completionCount == 0) null else totalCompletionMs / completionCount

    /** For `/csafari session reset`: wipes this session's stats back to zero. */
    fun reset() {
        completionCount = 0
        totalCompletionMs = 0L
        pbElapsedMs = null
    }
}
