package dev.xispana.safari

import net.minecraft.client.Minecraft
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.player.Player

/**
 * Scans nearby entities for Sparkling critters, two different ways, since neither alone is
 * reliable:
 *
 * 1. Nametag text containing "SPARKLING" - works for most of them, cheap and exact once it
 *    matches, but per your report some Sparkling critters don't actually have that word in
 *    their nametag at all.
 * 2. For critters #1 misses: resolve the entity's plain name (no "SPARKLING" needed) via
 *    Critters.matchAtStart, then check ParticleTracker for a shiny-looking particle recorded
 *    near that entity very recently (the cross/glint effect in your screenshot). This is the
 *    fallback for exactly the case you described - "Honeybug" with no "SPARKLING" text but the
 *    sparkle visual still playing around it.
 *
 * SHINY_PARTICLE_HINTS below used to be a best-effort guess list (totem_of_undying, end_rod,
 * firework, witch, enchant, crit) - too broad, and per your report `end_rod` was false-
 * flagging on unrelated particles. Replaced with the real id you confirmed via
 * `/csafari particles`: `wax_on` (the same particle vanilla uses for an axe un-waxing copper -
 * reused here, evidently, for the shiny glint).
 *
 * Scoped to an active safari run (Sparkling critters only exist there) and throttled to every
 * 5 ticks (4 scans/sec) - a full nearby-entity scan every single tick isn't needed for
 * something that only has to feel responsive, not instant.
 */
object SparklingHighlighter {

    var enabled: Boolean = true

    private const val MATCH = "sparkling"
    private const val SCAN_INTERVAL_TICKS = 5
    private var tickCounter = 0

    // Confirmed via /csafari particles - the only particle id the shiny effect actually uses.
    val SHINY_PARTICLE_HINTS: Set<String> = setOf("wax_on")
    private const val PARTICLE_RADIUS = 2.5
    private const val PARTICLE_MAX_AGE_MS = 1500L

    @Volatile
    var nearby: Boolean = false
        private set

    /** Display names of the currently-matched Sparkling critter(s), for the on-screen label. */
    @Volatile
    var names: Set<String> = emptySet()
        private set

    // Entity ids matched on the previous scan, so the sound only fires when a NEW critter
    // starts matching rather than retriggering every scan while one stays in range.
    private var previouslyMatched: Set<Int> = emptySet()

    // Keyed by critter NAME, not entity id. It was id-keyed at first, but per your report a
    // failed catch attempt respawns the Sparkling as a brand new entity (new id, same name) -
    // which the id-keyed cooldown saw as a totally different critter and let the sound replay
    // every single failed attempt. Keying by name instead means "the same Sparkling" is
    // recognized across that respawn. Two DIFFERENT Sparklings at once still each get their
    // own sound, since they resolve to different names. nearby/names (and therefore the
    // border) are completely untouched by this and keep updating live the whole time.
    private const val SOUND_COOLDOWN_MS = 60_000L
    private val lastSoundMsByName = mutableMapOf<String, Long>()

    /** One scanned entity's result, for the /csafari sparkling debug command - lets you check
     *  what the last scan actually saw and matched without needing to spot the border in game. */
    data class ScanEntry(
        val entityId: Int,
        val rawText: String,
        val critterGuess: String?,
        val matched: Boolean
    )

    @Volatile
    var lastScan: List<ScanEntry> = emptyList()
        private set

    fun tick() {
        if (!enabled || SafariTracker.currentRun == null) {
            nearby = false
            names = emptySet()
            previouslyMatched = emptySet()
            tickCounter = 0
            return
        }
        tickCounter++
        if (tickCounter < SCAN_INTERVAL_TICKS) return
        tickCounter = 0

        val level = Minecraft.getInstance().level
        if (level == null) {
            nearby = false
            names = emptySet()
            return
        }

        // Maps entity id -> resolved critter name for everything matched this scan. Built as
        // one map (not two separate sets) specifically so a newly-appearing id can be turned
        // straight back into its name below, without a second lookup pass.
        val matchedIdToName = mutableMapOf<Int, String>()
        val scanLog = mutableListOf<ScanEntry>()

        for (entity in level.entitiesForRendering()) {
            val name = resolveSparklingName(entity, scanLog) ?: continue
            matchedIdToName[entity.id] = name
        }

        nearby = matchedIdToName.isNotEmpty()
        names = matchedIdToName.values.toSet()
        lastScan = scanLog

        // Fire the alert sound once per newly-appearing entity id (so a brand new entity -
        // including a respawn right after a failed catch - still "tries" to play), but the
        // per-NAME cooldown inside playShinySound is what actually decides whether it's
        // allowed to, so that same critter respawning after a failed catch doesn't replay it.
        for ((id, name) in matchedIdToName) {
            if (id !in previouslyMatched) playShinySound(name)
        }
        previouslyMatched = matchedIdToName.keys.toSet()
    }

    /**
     * Returns a display name if [entity] looks like a Sparkling critter, or null. Tries the
     * literal-text match first (cheap, exact), then falls back to particle proximity for
     * critters whose nametag doesn't say "SPARKLING". Every candidate it looks at - matched or
     * not - gets appended to [debug] so /csafari sparkling debug can show the full scan.
     */
    private fun resolveSparklingName(entity: Entity, debug: MutableList<ScanEntry>): String? {
        val rawTexts = listOfNotNull(
            (entity as? Player)?.gameProfile?.name,
            entity.customName?.string
        )

        // Channel 1: literal "SPARKLING" text somewhere in the name.
        for (raw in rawTexts) {
            if (!raw.lowercase().contains(MATCH)) continue
            // Strip the "SPARKLING" marker (any case/position) and resolve what's left to a
            // real critter name; fall back to the cleaned raw text if it doesn't resolve.
            val stripped = Regex("(?i)sparkling").replace(raw, "").trim()
            val resolved = Critters.matchAtStart(stripped)?.name ?: stripped.ifBlank { raw.trim() }
            debug.add(ScanEntry(entity.id, raw, resolved, matched = true))
            return resolved
        }

        // Channel 2: no "SPARKLING" text, but the raw name resolves to a real critter AND a
        // shiny-looking particle was recorded near this entity very recently.
        for (raw in rawTexts) {
            val critter = Critters.matchAtStart(raw.trim()) ?: continue
            val near = ParticleTracker.hasNearby(
                entity.x, entity.y, entity.z,
                PARTICLE_RADIUS, SHINY_PARTICLE_HINTS, PARTICLE_MAX_AGE_MS
            )
            debug.add(ScanEntry(entity.id, raw, critter.name, matched = near))
            if (near) return critter.name
        }

        return null
    }

    private fun playShinySound(critterName: String) {
        val now = System.currentTimeMillis()
        val last = lastSoundMsByName[critterName]
        if (last != null && now - last < SOUND_COOLDOWN_MS) return
        lastSoundMsByName[critterName] = now
        // Plays whichever jingle is currently selected - /csafari shinysound to cycle, or
        // /csafari shinysound <pokemon|wynncraft> to pick one directly. See ShinySoundConfig
        // for the options and persistence.
        ShinySoundConfig.play()
    }
}
